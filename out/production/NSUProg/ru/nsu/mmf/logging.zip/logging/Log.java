package ru.nsu.mmf.logging;

import java.time.LocalDateTime;

public class Log {
    private ILog loadder;
    private int level; // 0 <= level <= 5



    public Log(String fileName, int level) {
        this.level = level;
        this.loadder = new FileLoader(fileName);
    }

    public Log(String fileName, String level) {
        this(fileName, 0);
        this.level = levelCheck(level);
    }


    public Log(String level) {
        this(0);
        this.level = levelCheck(level);
    }

    public Log (int level) {
        this.level = level;
        this.loadder = new ConsoleLoader();
    }



    private String time () {
        return LocalDateTime.now().toString();
    }



    public void trace(String message) {
        if (level == 5) loadder.trace(message + "  time: " + time());
    }


    public void debug(String message) {
        if (level >= 4) loadder.debug(message + "  time: " + time());
    }

    public void info(String message) {
        if (level >= 3) loadder.info(message + "  time: " + time());
    }

    public void warn(String message) {
        if (level >= 2) loadder.warn(message + "  time: " + time());

    }

    public void error(String message) {
        if (level >= 1) loadder.error(message + "  time: " + time());
    }

    public void fatal(String message) {
        if (level >= 0) loadder.fatal(message + "  time: " + time());
    }



    private int levelCheck (String str) {
        if (str.equals("trace")) return 5;

        if (str.equals("debug")) return 4;

        if (str.equals("info")) return 3;

        if (str.equals("warn")) return 2;

        if (str.equals("error")) return 1;

        if (str.equals("fatal")) return 0;

        throw new RuntimeException("Уровень логгирования неверно задан!");
    }


}
