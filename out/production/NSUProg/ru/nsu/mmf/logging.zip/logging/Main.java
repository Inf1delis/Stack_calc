package ru.nsu.mmf.logging;

public class Main {
    public static void main(String[] args) {

        Thread[] threads = new Thread[3];
        for (int i = 0; i < 3; i++) {
            threads[i] = new Thread(new MyRunneble());
            threads[i].start();
        }

    }
}
