package ru.nsu.mmf.logging;

public class MyRunneble implements  Runnable {

    @Override
    public void run() {
        Log log = new Log(5);
        for (int i = 0; i <  10000; i++) {
            log.trace(Thread.currentThread().getName());
        }
    }
}
